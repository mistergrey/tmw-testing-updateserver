<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Crypt-Fringe" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/Crypt-Fringe.png" width="512" height="512"/>
</tileset>
