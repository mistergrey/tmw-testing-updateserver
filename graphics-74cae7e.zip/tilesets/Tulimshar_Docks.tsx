<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tulimshar_Docks" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/Tulimshar_Docks.png" width="512" height="320"/>
</tileset>
