<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Forest" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/Forest.png" width="608" height="672"/>
</tileset>
