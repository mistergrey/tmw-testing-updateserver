<?xml version="1.0" encoding="UTF-8"?>
<tileset name="barbarians-outdoor" tilewidth="64" tileheight="64">
 <image source="../graphics/tiles/barbarians-outdoor.png" width="192" height="64"/>
</tileset>
